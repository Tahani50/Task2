//
//  ContentView.swift
//  ClassTask1
//
//  Created by Taibah Valley Academy on 3/4/25.
//

import SwiftUI

struct ContentView: View {
    
    @State var names = ["Alice", "Bob", "Charlie", "Tahani", "Zahra"]
    @State var searchText: String = ""
    @State var isSorted = true
    
    
    var body: some View {
        VStack {
            List(searchResults, id: \.self){
                name in Text(name)
            }
        }
        .searchable(text: $searchText)
        
        Button(isSorted ? "Sort" : "Shuffle"){
            isSorted.toggle()
            names = isSorted ? names.sorted() : names.shuffled()
        }
        .padding()
    }
    var searchResults: [String]{
        if searchText.isEmpty {
            return names
        }else {
            return names.filter{$0.contains(searchText)}
        }
    }
}

#Preview {
    ContentView()
}
