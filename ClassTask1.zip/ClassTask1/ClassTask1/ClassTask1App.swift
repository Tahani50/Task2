//
//  ClassTask1App.swift
//  ClassTask1
//
//  Created by Taibah Valley Academy on 3/4/25.
//

import SwiftUI

@main
struct ClassTask1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
